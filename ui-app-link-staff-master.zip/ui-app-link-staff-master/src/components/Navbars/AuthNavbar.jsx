import React from "react";

class UserNavbar extends React.Component {
  render() {
    return (
      <>
        Auth Nav
      </>
    );
  }
}

export default UserNavbar;
