export const LOGIN_USER =
  'src/modules/auth/LOGIN_USER';
export const REGISTER_USER =
  'src/modules/auth/REGISTER_USER';
export const LIST_EDUCATION_INSTITUTE =
  'src/modules/auth/LIST_EDUCATION_INSTITUTE';
export const CANCEL_ALL_API_REQUESTS =
  'src/modules/auth/CANCEL_ALL_API_REQUESTS';
